-- inserts

insert into room_hotel values (213,'Hotel Marigold', 'small', 2, 'simple', 35, 6, 'Piazza Dante 4 Capri IT', 003977877810);
insert into room_hotel values (601,'Hotel Marigold', 'medium', 3, 'luxe', 150, 6, 'Piazza Dante 4 Capri IT', 003977877810);
insert into room_hotel values (404,'Hotel Marigold', 'big', 2, 'couples', 80, 6, 'Piazza Dante 4 Capri IT', 003977877810);

insert into room_hotel values (213,'Hotel Romeo', 'small', 2, 'simple', 35, 6, 'Strada del Porto 13 Napoli IT', 003989977110);
insert into room_hotel values (601,'Hotel Romeo', 'big', 3, 'standard', 39.90, 2, 'Strada del Porto 13 Napoli IT', 003989977110);
